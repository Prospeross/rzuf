// copy this file to wifikeys.h and edit
const char *ssid =     "YOURNETHERE";         // Put your SSID here
const char *password = "YOURPASSWORDHERE";     // Put your PASSWORD here
